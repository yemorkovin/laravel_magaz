
<?php $__env->startSection('title', 'Главная'); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
        <div class="carousel">
            <div class="carousel-window">
                <div class="carousel-slides">
                    <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="carousel-item">
                        <img src="/storage/<?php echo e($slider->img); ?>" alt="">
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   
                </div>
            </div>
            <a href="#" class="carousel-prev" style="display: none">
                <span class="carousel-prev-icon">&lt;</span>
            </a>
            <a href="#" class="carousel-next" style="display: none">
                <span class="carousel-next-icon">&gt;</span>
            </a>
        </div>
    </div>
<div class="menu_1">
		<ul>
			<li>
				<a href="#" class="active">
					популярное
				</a>
			</li>
            <?php $__currentLoopData = $cats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<li>
				<a href="#">
					<?php echo e($cat->title); ?>

				</a>
			</li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			
		</ul>
	</div>
	<div class="cat_1">
        
    <?php $__currentLoopData = \App\Models\Product::where('pop', 1)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<div class="item_cat_1"  >
			<img src="/storage/<?php echo e($pr->img); ?>" class="img_cat_1 imf_addd_<?php echo e($pr->id); ?>" alt="<?php echo e($pr->title); ?>">
			<h2 onclick="window.location.replace('/product/<?php echo e($pr->id); ?>')"><?php echo e($pr->title); ?></h2>
			<p class="description"><?php echo e($pr->description); ?></p>
			<p class="price"><?php echo e(number_format($pr->price, 0, ',', ' ')); ?> ₽</p>
			<div class="circle_list">
                <?php $__currentLoopData = explode(',', $pr->colors); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<div style="background: <?php echo e($p); ?>;" class="colborder col_<?php echo e($key); ?>_<?php echo e($pr->id); ?>" onclick="selectcolor(<?php echo e($pr->id); ?>,<?php echo e($key); ?>)">

				</div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				
			</div>
		</div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	
		
	
		
	</div>
	<div class="new_r">
		<div class="new_r_title">
			<h2>Новинки</h2>
			<p>Все новые товары <img src="images/right.png"></p>
		</div>
		
	</div>
	<div class="cat_1">
    <?php $__currentLoopData = \App\Models\Product::where('new', 1)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<div class="item_cat_1">
			<img src="/storage/<?php echo e($pr->img); ?>" class="img_cat_1 imf_addd_<?php echo e($pr->id); ?>">
			<h2 onclick="window.location.replace('/product/<?php echo e($pr->id); ?>')"><?php echo e($pr->title); ?></h2>
			<p class="description"><?php echo e($pr->description); ?></p>
			<p class="price"><?php echo e(number_format($pr->price, 0, ',', ' ')); ?> ₽</p>
			<div class="circle_list">
            <?php $__currentLoopData = explode(',', $pr->colors); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<div style="background: <?php echo e($p); ?>" class="colborder col_<?php echo e($key); ?>_<?php echo e($pr->id); ?>" onclick="selectcolor(<?php echo e($pr->id); ?>,<?php echo e($key); ?>)">

				</div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				
			</div>
		</div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		
		
		
		
	</div>


	<div class="new_r">
		<div class="new_r_title">
			<h2>Идеи для интерьеров</h2>
			<p>Все идеи <img src="images/right.png"></p>
		</div>
		
	</div>
	<div class="cat_1">
	<?php $__currentLoopData = \App\Models\Idea::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<div class="item_cat_1">
			<img src="/storage/<?php echo e($pr->img); ?>" class="img_cat_1">
			
		</div>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		
		
	</div>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OpenServer\domains\myproject\resources\views/index.blade.php ENDPATH**/ ?>